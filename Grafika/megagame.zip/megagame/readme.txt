﻿The font file in this archive was created using a digital font-building tool.
This font was designed by “equeueo”.

LEGAL NOTICE:
By using this font, youagree to comply with the terms described in the license.txt file included with this archive.
If you redistribute this font, all files from this archive must remain together, including this document.
